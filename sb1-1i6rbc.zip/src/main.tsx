import { StrictMode, lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Home } from './pages/Home';
import { SignIn } from './pages/SignIn';
import { SignUp } from './pages/SignUp';
import { Account } from './pages/Account';
import { ResetPassword } from './pages/ResetPassword';
import { Pricing } from './pages/Pricing';
import { VerifyEmail } from './pages/VerifyEmail';
import { AuthGuard } from './components/AuthGuard';
import './index.css';

const App = lazy(() => import('./App'));

const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/signin',
    element: <SignIn />,
  },
  {
    path: '/signup',
    element: <SignUp />,
  },
  {
    path: '/pricing',
    element: <Pricing />,
  },
  {
    path: '/reset-password',
    element: <ResetPassword />,
  },
  {
    path: '/verify-email',
    element: <VerifyEmail />,
  },
  {
    path: '/account',
    element: (
      <AuthGuard>
        <Account />
      </AuthGuard>
    ),
  },
  {
    path: '/app',
    element: (
      <AuthGuard>
        <App />
      </AuthGuard>
    ),
  },
]);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Suspense fallback={<div className="min-h-screen bg-gray-900" />}>
      <RouterProvider router={router} />
    </Suspense>
  </StrictMode>
);
