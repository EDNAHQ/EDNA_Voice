import React from 'react';
import { Link } from 'react-router-dom';
import { Check, Box } from 'lucide-react';

const tiers = [
  {
    name: 'Basic',
    price: '$19',
    period: '/month',
    description: 'Perfect for individuals and small projects',
    features: [
      'Up to 100 minutes of synthesis per month',
      '2 custom voices',
      'All synthesis styles',
      'Standard support',
      'Basic analytics',
    ],
    buttonText: 'Get Started',
    buttonLink: '/signup',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '$49',
    period: '/month',
    description: 'For professionals and growing teams',
    features: [
      'Up to 500 minutes of synthesis per month',
      '10 custom voices',
      'All synthesis styles',
      'Priority support',
      'Advanced analytics',
      'API access',
      'Custom webhooks',
    ],
    buttonText: 'Try Pro',
    buttonLink: '/signup?plan=pro',
    highlighted: true,
  },
];

export function Pricing() {
  return (
    <div className="min-h-screen bg-gray-900 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Box className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-white mb-4">
            Simple, transparent pricing
          </h1>
          <p className="text-xl text-gray-400">
            Choose the perfect plan for your needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`rounded-lg p-8 ${
                tier.highlighted
                  ? 'bg-green-500/10 border-2 border-green-500'
                  : 'bg-gray-800/50 border-2 border-gray-700'
              }`}
            >
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-white mb-2">
                  {tier.name}
                </h2>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-4xl font-bold text-white">
                    {tier.price}
                  </span>
                  <span className="text-gray-400">{tier.period}</span>
                </div>
                <p className="text-gray-400 mt-4">{tier.description}</p>
              </div>

              <ul className="space-y-4 mb-8">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className={`w-5 h-5 mt-0.5 ${
                      tier.highlighted ? 'text-green-500' : 'text-gray-400'
                    }`} />
                    <span className="text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                to={tier.buttonLink}
                className={`block w-full py-3 px-4 rounded-lg text-center font-medium transition-colors ${
                  tier.highlighted
                    ? 'bg-green-500 hover:bg-green-600 text-white'
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
              >
                {tier.buttonText}
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <p className="text-gray-400">
            Need a custom plan?{' '}
            <a href="mailto:sales@play.ai" className="text-green-500 hover:text-green-400">
              Contact us
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}