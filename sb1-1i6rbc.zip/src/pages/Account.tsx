import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { User, Settings, Key, LogOut, CreditCard } from 'lucide-react';
import { SubscriptionStatus } from '../components/SubscriptionStatus';
import { stripe } from '../services/stripe';

export function Account() {
  const { user, logout } = useAuthStore();
  const subscription = useSubscriptionStore((state) => state.subscription);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleManageSubscription = async () => {
    if (user?.stripeCustomerId) {
      await stripe.createPortalSession(user.stripeCustomerId);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gray-800 rounded-lg p-6 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-green-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{user?.name}</h1>
              <p className="text-gray-400">{user?.email}</p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Subscription</h2>
          <SubscriptionStatus />
          {subscription && (
            <button
              onClick={handleManageSubscription}
              className="mt-4 w-full bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg flex items-center justify-center gap-2 transition-colors"
            >
              <CreditCard className="w-4 h-4" />
              Manage Subscription
            </button>
          )}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <button className="bg-gray-800 p-4 rounded-lg hover:bg-gray-700 transition-colors">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-green-500" />
              <div className="text-left">
                <div className="font-medium text-white">Account Settings</div>
                <div className="text-sm text-gray-400">
                  Manage your account preferences
                </div>
              </div>
            </div>
          </button>

          <button className="bg-gray-800 p-4 rounded-lg hover:bg-gray-700 transition-colors">
            <div className="flex items-center gap-3">
              <Key className="w-5 h-5 text-green-500" />
              <div className="text-left">
                <div className="font-medium text-white">Security</div>
                <div className="text-sm text-gray-400">
                  Update your password and security settings
                </div>
              </div>
            </div>
          </button>
        </div>

        <button
          onClick={handleLogout}
          className="mt-8 w-full bg-red-500/10 text-red-500 py-2 rounded-lg hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );
}