import React from 'react';
import { Link } from 'react-router-dom';
import { Box, ArrowRight } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <Box className="w-16 h-16 text-green-500 mx-auto mb-8" />
          <h1 className="text-5xl font-bold text-white mb-6">
            Transform Text to Natural Speech
          </h1>
          <p className="text-xl text-gray-400 mb-8">
            Create natural-sounding voice content from any text using advanced AI
            technology. Perfect for podcasts, narration, and more.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              to="/signup"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 transition-colors"
            >
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/signin"
              className="bg-gray-800 hover:bg-gray-700 text-white px-8 py-3 rounded-lg font-medium transition-colors"
            >
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}