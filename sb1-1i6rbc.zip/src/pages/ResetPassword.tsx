import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Box, ArrowLeft, Mail } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export function ResetPassword() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const resetPassword = useAuthStore((state) => state.resetPassword);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    resetPassword(email);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <Link
            to="/signin"
            className="inline-flex items-center gap-2 text-green-500 hover:text-green-400 mb-8"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Sign In
          </Link>
          <Box className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white">Reset your password</h1>
        </div>

        {submitted ? (
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
              <Mail className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-xl font-medium text-white">Check your email</h2>
            <p className="text-gray-400">
              We've sent password reset instructions to {email}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">
                Email address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-green-500"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-medium transition-colors"
            >
              Send Reset Instructions
            </button>
          </form>
        )}
      </div>
    </div>
  );
}