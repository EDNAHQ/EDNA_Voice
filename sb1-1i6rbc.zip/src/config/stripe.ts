export const STRIPE_CONFIG = {
  publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || 'pk_test_your_key',
  secretKey: process.env.STRIPE_SECRET_KEY || 'sk_test_your_key',
  webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || 'whsec_your_key',
  products: {
    basic: {
      id: 'price_basic',
      name: 'Basic Plan',
      price: 19,
      limits: {
        minutes: 100,
        voices: 2,
      },
      features: [
        'Up to 100 minutes of synthesis per month',
        '2 custom voices',
        'All synthesis styles',
        'Standard support',
        'Basic analytics',
      ],
    },
    pro: {
      id: 'price_pro',
      name: 'Pro Plan',
      price: 49,
      limits: {
        minutes: 500,
        voices: 10,
      },
      features: [
        'Up to 500 minutes of synthesis per month',
        '10 custom voices',
        'All synthesis styles',
        'Priority support',
        'Advanced analytics',
        'API access',
        'Custom webhooks',
      ],
    },
  },
} as const;