export const PLAYAI_CONFIG = {
  API_KEY: 'ak-f986cb62d99f433fa3e4296de43f1314',
  API_URL: 'https://api.play.ai/api/v1',
  SUPPORTED_FILE_TYPES: [
    '.pdf', '.csv', '.txt', '.epub', '.docx', '.xls',
    '.png', '.jpeg', '.jpg', '.webp', '.mp4'
  ],
  MAX_FILE_SIZE: 50 * 1024 * 1024, // 50MB
  DEFAULT_VOICES: {
    VOICE1: {
      url: 's3://voice-cloning-zero-shot/e040bd1b-f190-4bdb-83f0-75ef85b18f84/original/manifest.json',
      name: 'Deedee',
      gender: 'female'
    },
    VOICE2: {
      url: 's3://voice-cloning-zero-shot/baf1ef41-36b6-428c-9bdf-50ba54682bd8/original/manifest.json',
      name: 'Angelo',
      gender: 'male'
    }
  },
  SYNTHESIS_STYLES: [
    {
      id: 'podcast',
      name: 'Podcast',
      speakers: 2,
      description: 'in the conversational style of a podcast'
    },
    {
      id: 'executive',
      name: 'Executive Briefing',
      speakers: 1,
      description: 'in the succinct style of a professional briefing'
    },
    {
      id: 'children',
      name: 'Children\'s Story',
      speakers: 1,
      description: 'in the imaginative, colorful style of a children\'s book author'
    },
    {
      id: 'debate',
      name: 'Debate',
      speakers: 2,
      description: 'in the contentious, aggressive style of a thoughtful discussion'
    },
    {
      id: 'summary',
      name: 'Detailed Summary',
      speakers: 1,
      description: 'a comprehensive and detailed summary of the content'
    },
    {
      id: 'parody',
      name: 'Parody',
      speakers: 1,
      description: 'a humorous and satirical take on the content'
    }
  ]
} as const;