import { useEffect } from 'react';
import { useSubscriptionStore } from '../store/subscriptionStore';
import { useAuthStore } from '../store/authStore';

export function useSubscription() {
  const { user } = useAuthStore();
  const { subscription, setSubscription, updateUsage } = useSubscriptionStore();

  useEffect(() => {
    if (user?.stripeCustomerId) {
      // Fetch subscription data from your API
      fetch(`/api/subscriptions/${user.stripeCustomerId}`)
        .then((res) => res.json())
        .then((data) => {
          setSubscription(data);
        })
        .catch(console.error);
    }
  }, [user, setSubscription]);

  const trackUsage = async (feature: 'minutes' | 'voices', amount: number = 1) => {
    if (!subscription || !user) return;

    try {
      const response = await fetch('/api/usage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: user.stripeCustomerId,
          feature,
          amount,
        }),
      });

      const data = await response.json();
      updateUsage({ [feature]: data.total });
    } catch (error) {
      console.error('Error tracking usage:', error);
    }
  };

  return { subscription, trackUsage };
}