import { useState, useEffect } from 'react';
import { playai } from '../services/playai';
import { analytics } from '../utils/analytics';

interface UsePlayAIOptions {
  sourceFileUrl?: string;
  synthesisStyle?: string;
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
}

export function usePlayAI(options: UsePlayAIOptions = {}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [playNoteId, setPlayNoteId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const synthesize = async () => {
    if (!options.sourceFileUrl || !options.synthesisStyle) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await playai.synthesize({
        sourceFileUrl: options.sourceFileUrl,
        synthesisStyle: options.synthesisStyle as any,
      });

      setPlayNoteId(response.data?.id);
      options.onSuccess?.(response.data);
      
      analytics.trackEvent('synthesis_started', {
        style: options.synthesisStyle,
        fileUrl: options.sourceFileUrl,
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Synthesis failed');
      setError(error);
      options.onError?.(error);
      
      analytics.trackError(error, {
        context: 'synthesis',
        style: options.synthesisStyle,
        fileUrl: options.sourceFileUrl,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    if (playNoteId) {
      intervalId = setInterval(async () => {
        try {
          const response = await playai.getPlayNoteStatus(playNoteId);
          setStatus(response.data?.status);

          if (['completed', 'failed'].includes(response.data?.status)) {
            clearInterval(intervalId);
          }
        } catch (error) {
          console.error('Failed to fetch status:', error);
        }
      }, 5000);
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [playNoteId]);

  return {
    synthesize,
    loading,
    error,
    status,
    playNoteId,
  };
}