import { useState, useEffect } from 'react';

const CACHE_PREFIX = 'audio_cache_';
const MAX_CACHE_SIZE = 50 * 1024 * 1024; // 50MB

interface CacheEntry {
  url: string;
  data: ArrayBuffer;
  timestamp: number;
  size: number;
}

export function useAudioCache(url: string | null) {
  const [audioData, setAudioData] = useState<ArrayBuffer | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!url) return;

    const fetchAndCacheAudio = async () => {
      setLoading(true);
      setError(null);

      try {
        // Check cache first
        const cachedData = await getCachedAudio(url);
        if (cachedData) {
          setAudioData(cachedData);
          setLoading(false);
          return;
        }

        // Fetch and cache if not found
        const response = await fetch(url);
        const buffer = await response.arrayBuffer();
        
        await cacheAudio(url, buffer);
        setAudioData(buffer);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to load audio'));
      } finally {
        setLoading(false);
      }
    };

    fetchAndCacheAudio();
  }, [url]);

  return { audioData, loading, error };
}

async function getCachedAudio(url: string): Promise<ArrayBuffer | null> {
  const cache = await caches.open(CACHE_PREFIX + 'v1');
  const response = await cache.match(url);
  if (response) {
    return response.arrayBuffer();
  }
  return null;
}

async function cacheAudio(url: string, data: ArrayBuffer): Promise<void> {
  const cache = await caches.open(CACHE_PREFIX + 'v1');
  
  // Check cache size and clear old entries if needed
  await maintainCacheSize();
  
  const response = new Response(data);
  await cache.put(url, response);
}

async function maintainCacheSize(): Promise<void> {
  const cache = await caches.open(CACHE_PREFIX + 'v1');
  const keys = await cache.keys();
  
  let totalSize = 0;
  const entries: CacheEntry[] = [];

  for (const key of keys) {
    const response = await cache.match(key);
    if (response) {
      const data = await response.clone().arrayBuffer();
      entries.push({
        url: key.url,
        data,
        timestamp: new Date(response.headers.get('date') || Date.now()).getTime(),
        size: data.byteLength,
      });
      totalSize += data.byteLength;
    }
  }

  if (totalSize > MAX_CACHE_SIZE) {
    // Sort by timestamp and remove oldest entries
    entries.sort((a, b) => b.timestamp - a.timestamp);
    
    while (totalSize > MAX_CACHE_SIZE && entries.length > 0) {
      const entry = entries.pop();
      if (entry) {
        await cache.delete(entry.url);
        totalSize -= entry.size;
      }
    }
  }
}