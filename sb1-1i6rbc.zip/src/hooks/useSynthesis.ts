import { useState, useCallback } from 'react';
import { playai } from '../services/playai';
import { tts } from '../services/tts';
import { analytics } from '../utils/analytics';

interface UseSynthesisOptions {
  onSuccess?: (audioUrl: string) => void;
  onError?: (error: Error) => void;
  onProgress?: (status: string) => void;
}

export function useSynthesis(options: UseSynthesisOptions = {}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const synthesizeFromFile = useCallback(async (fileUrl: string, style: string) => {
    setLoading(true);
    setError(null);
    setStatus('starting');

    try {
      const response = await playai.synthesize({
        sourceFileUrl: fileUrl,
        synthesisStyle: style as any,
      });

      if (response.data?.id) {
        // Start polling for status
        const pollStatus = async () => {
          const statusResponse = await playai.getPlayNoteStatus(response.data!.id);
          
          if (statusResponse.data?.status) {
            setStatus(statusResponse.data.status);
            options.onProgress?.(statusResponse.data.status);

            if (statusResponse.data.status === 'completed' && statusResponse.data.audioUrl) {
              options.onSuccess?.(statusResponse.data.audioUrl);
            } else if (statusResponse.data.status === 'failed') {
              throw new Error('Synthesis failed');
            } else {
              // Continue polling
              setTimeout(pollStatus, 2000);
            }
          }
        };

        await pollStatus();
      }

      analytics.trackEvent('synthesis_started', {
        style,
        fileType: 'url',
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Synthesis failed');
      setError(error);
      options.onError?.(error);
      
      analytics.trackError(error, {
        context: 'synthesis',
        style,
      });
    } finally {
      setLoading(false);
    }
  }, [options]);

  const synthesizeFromText = useCallback(async (text: string, voice?: string) => {
    setLoading(true);
    setError(null);
    setStatus('starting');

    try {
      const response = await tts.synthesize({
        text,
        voice,
      });

      if (response.jobId) {
        await tts.pollJobStatus(response.jobId, (job) => {
          setStatus(job.status);
          options.onProgress?.(job.status);

          if (job.status === 'completed' && job.audioUrl) {
            options.onSuccess?.(job.audioUrl);
          }
        });
      }

      analytics.trackEvent('tts_synthesis_started', {
        textLength: text.length,
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('TTS synthesis failed');
      setError(error);
      options.onError?.(error);
      
      analytics.trackError(error, {
        context: 'tts_synthesis',
        textLength: text.length,
      });
    } finally {
      setLoading(false);
    }
  }, [options]);

  return {
    synthesizeFromFile,
    synthesizeFromText,
    loading,
    error,
    status,
  };
}