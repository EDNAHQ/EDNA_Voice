import { useState, useEffect } from 'react';
import { tts } from '../services/tts';
import { analytics } from '../utils/analytics';

interface UseTTSOptions {
  text?: string;
  voice?: string;
  voice2?: string;
  onSuccess?: (audioUrl: string) => void;
  onError?: (error: Error) => void;
}

export function useTTS(options: UseTTSOptions = {}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const synthesize = async (text?: string) => {
    const textToProcess = text || options.text;
    if (!textToProcess) return;

    setLoading(true);
    setError(null);

    try {
      const response = await tts.synthesize({
        text: textToProcess,
        voice: options.voice,
        voice2: options.voice2,
      });

      setJobId(response.jobId);
      setStatus(response.status);
      
      analytics.trackEvent('tts_synthesis_started', {
        textLength: textToProcess.length,
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('TTS synthesis failed');
      setError(error);
      options.onError?.(error);
      
      analytics.trackError(error, {
        context: 'tts_synthesis',
        textLength: textToProcess.length,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    if (jobId && status !== 'completed' && status !== 'failed') {
      intervalId = setInterval(async () => {
        try {
          const response = await tts.getJobStatus(jobId);
          setStatus(response.status);

          if (response.audioUrl) {
            setAudioUrl(response.audioUrl);
            options.onSuccess?.(response.audioUrl);
          }

          if (['completed', 'failed'].includes(response.status)) {
            clearInterval(intervalId);
          }
        } catch (error) {
          console.error('Failed to fetch TTS status:', error);
        }
      }, 2000);
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [jobId, status, options.onSuccess]);

  return {
    synthesize,
    loading,
    error,
    status,
    audioUrl,
    jobId,
  };
}