import { PLAYAI_CONFIG } from '../config/constants';

interface TTSOptions {
  text: string;
  outputFormat?: 'mp3' | 'wav';
  language?: string;
  speed?: number;
  model?: string;
  voice?: string;
  voice2?: string;
}

interface TTSJob {
  jobId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  audioUrl?: string;
  error?: string;
  createdAt: string;
  updatedAt: string;
}

const headers = {
  'Authorization': `Bearer ${PLAYAI_CONFIG.API_KEY}`,
  'X-USER-ID': 'fwz2bkcxZ9ekBoFATevNsnMmkft1',
  'Content-Type': 'application/json',
};

export const tts = {
  synthesize: async (options: TTSOptions): Promise<TTSJob> => {
    try {
      const response = await fetch(`${PLAYAI_CONFIG.API_URL}/tts`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          outputFormat: 'mp3',
          language: 'english',
          speed: 1,
          model: 'PlayDialog',
          ...options,
          voice: options.voice || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE1.url,
          voice2: options.voice2 || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE2.url,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('TTS API Error:', error);
      throw new Error('Failed to start TTS synthesis');
    }
  },

  getJobStatus: async (jobId: string): Promise<TTSResponse> => {
    try {
      const response = await fetch(`${PLAYAI_CONFIG.API_URL}/tts/${jobId}`, {
        headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('TTS Status API Error:', error);
      throw error;
    }
  },

  pollJobStatus: async (jobId: string, onUpdate: (job: TTSJob) => void): Promise<void> => {
    const poll = async () => {
      try {
        const job = await tts.getJobStatus(jobId);
        onUpdate(job);

        if (job.status !== 'completed' && job.status !== 'failed') {
          setTimeout(poll, 2000); // Poll every 2 seconds
        }
      } catch (error) {
        console.error('TTS Status Polling Error:', error);
      }
    };

    await poll();
  },
};