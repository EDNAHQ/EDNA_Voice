import { useAuthStore } from '../store/authStore';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://api.example.com';

interface ApiResponse<T> {
  data?: T;
  error?: string;
}

async function fetchWithAuth(endpoint: string, options: RequestInit = {}) {
  const session = useAuthStore.getState().session;
  
  const headers = {
    'Content-Type': 'application/json',
    ...(session?.token && { Authorization: `Bearer ${session.token}` }),
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

export const api = {
  synthesize: async (text: string, voiceId: string): Promise<ApiResponse<{ audioUrl: string }>> => {
    return fetchWithAuth('/synthesize', {
      method: 'POST',
      body: JSON.stringify({ text, voiceId }),
    });
  },

  uploadFile: async (file: File, onProgress?: (progress: number) => void): Promise<ApiResponse<{ fileUrl: string }>> => {
    const formData = new FormData();
    formData.append('file', file);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      
      xhr.upload.addEventListener('progress', (event) => {
        if (event.lengthComputable && onProgress) {
          const progress = (event.loaded / event.total) * 100;
          onProgress(progress);
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(JSON.parse(xhr.response));
        } else {
          reject(new Error(`Upload failed: ${xhr.status}`));
        }
      });

      xhr.addEventListener('error', () => reject(new Error('Upload failed')));
      
      xhr.open('POST', `${API_BASE_URL}/upload`);
      xhr.send(formData);
    });
  },

  getVoices: async (): Promise<ApiResponse<Array<{ id: string; name: string }>>> => {
    return fetchWithAuth('/voices');
  },
};