import { PLAYAI_CONFIG } from '../config/constants';

interface PlayAIResponse<T> {
  data?: T;
  error?: string;
  status?: string;
  message?: string;
}

interface PlayNote {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  audioUrl?: string;
  duration?: number;
  createdAt: string;
  updatedAt: string;
}

interface SynthesisOptions {
  sourceFileUrl: string;
  synthesisStyle: 'podcast' | 'executive' | 'children' | 'debate' | 'summary' | 'parody';
  voice1?: string;
  voice1Name?: string;
  voice1Gender?: 'male' | 'female';
  voice2?: string;
  voice2Name?: string;
  voice2Gender?: 'male' | 'female';
  webHookUrl?: string;
}

const headers = {
  'Authorization': `Bearer ${PLAYAI_CONFIG.API_KEY}`,
  'X-USER-ID': 'fwz2bkcxZ9ekBoFATevNsnMmkft1',
  'Content-Type': 'application/json',
};

export const playai = {
  synthesize: async (options: SynthesisOptions): Promise<PlayAIResponse<PlayNote>> => {
    try {
      const response = await fetch(`${PLAYAI_CONFIG.API_URL}/playnotes`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ...options,
          voice1: options.voice1 || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE1.url,
          voice1Name: options.voice1Name || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE1.name,
          voice1Gender: options.voice1Gender || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE1.gender,
          voice2: options.voice2 || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE2.url,
          voice2Name: options.voice2Name || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE2.name,
          voice2Gender: options.voice2Gender || PLAYAI_CONFIG.DEFAULT_VOICES.VOICE2.gender,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('PlayAI API Error:', error);
      throw new Error('Failed to start synthesis');
    }
  },

  getPlayNoteStatus: async (playNoteId: string): Promise<PlayAIResponse> => {
    try {
      const response = await fetch(`${PLAYAI_CONFIG.API_URL}/playnotes/${playNoteId}`, {
        headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('PlayAI API Error:', error);
      throw error;
    }
  },
  
  getPlayNotes: async (): Promise<PlayAIResponse<PlayNote[]>> => {
    try {
      const response = await fetch(`${PLAYAI_CONFIG.API_URL}/playnotes`, {
        headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('PlayAI API Error:', error);
      throw new Error('Failed to fetch PlayNotes');
    }
  },
};