import React, { useState, useCallback, useEffect } from 'react';
import { FileUpload } from './components/FileUpload';
import { FileList } from './components/FileList';
import { UrlInput } from './components/UrlInput';
import { VoiceStyleCard } from './components/VoiceStyleCard';
import { VoiceSelector } from './components/VoiceSelector';
import { CreateVoiceButton } from './components/CreateVoiceButton';
import { PlayNoteList } from './components/PlayNoteList';
import { Header } from './components/Header';
import { TabToggle } from './components/TabToggle';
import { FilePreview } from './components/FilePreview';
import { VoiceCreator } from './components/VoiceCreator';
import { TranscriptInput } from './components/TranscriptInput';
import { ProgressSteps } from './components/ProgressSteps';
import { SearchBar } from './components/SearchBar';
import { FilterTabs } from './components/FilterTabs';
import { ProcessingStatus } from './components/ProcessingStatus';
import { TrainingProgress } from './components/TrainingProgress';
import {
  Mic,
  Users,
  BookOpen,
  MessageSquare,
  FileText,
  Theatre,
} from 'lucide-react';

function App() {
  const [selectedStyle, setSelectedStyle] = useState<string>('');
  const [selectedVoice, setSelectedVoice] = useState('deedee');
  const [activeTab, setActiveTab] = useState<'file' | 'transcript'>('file');
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [selectedFileIndex, setSelectedFileIndex] = useState<number | null>(null);
  const [showVoiceCreator, setShowVoiceCreator] = useState(false);
  const [showPlayNotes, setShowPlayNotes] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [processingStatus, setProcessingStatus] = useState<'idle' | 'processing' | 'complete' | 'error'>('idle');
  const [trainingProgress, setTrainingProgress] = useState({
    progress: 0,
    stage: 'Initializing',
    totalStages: 4,
    currentStage: 1
  });

  const progressSteps = [
    {
      label: 'Upload',
      completed: uploadedFiles.length > 0,
      active: uploadedFiles.length === 0,
    },
    {
      label: 'Style',
      completed: !!selectedStyle,
      active: uploadedFiles.length > 0 && !selectedStyle,
    },
    {
      label: 'Voice',
      completed: false,
      active: !!selectedStyle,
    },
  ];

  const filterTabs = [
    { id: 'all', label: 'All', count: demoNotes.length },
    { id: 'podcast', label: 'Podcast', count: 2 },
    { id: 'debate', label: 'Debate', count: 1 },
    { id: 'summary', label: 'Summary', count: 1 },
  ];

  const demoNotes = [
    {
      title: 'Vanna: A User-Friendly Toolkit for SQL Interaction',
      duration: '6:52',
      type: 'DEBATE' as const,
    },
    {
      title: 'Vanna: A Python Framework for RAG-based SQL Generation',
      duration: '3:27',
      type: 'PODCAST' as const,
    },
    {
      title: 'AI Voice Assistant with Avatar Chat',
      duration: '11:09',
      type: 'DETAILED-SUMMARY' as const,
      locked: true,
    },
  ];

  const handleFileSelect = useCallback((file: File) => {
    setUploadedFiles(prev => [...prev, file]);
    setSelectedFileIndex(prev => (prev === null ? 0 : prev));
  }, []);

  const handleRemoveFile = useCallback((index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
    setSelectedFileIndex(null);
  }, []);

  const handleFileClick = useCallback((index: number) => {
    setSelectedFileIndex(index);
  }, []);

  const handleUrlSubmit = useCallback((url: string) => {
    console.log('Fetching content from:', url);
    // Implementation for fetching content would go here
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <Header />
        
        <div className="mb-6 space-y-4">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search your PlayNotes..."
          />
          <FilterTabs
            tabs={filterTabs}
            activeTab={activeFilter}
            onTabChange={setActiveFilter}
          />
        </div>

        {showPlayNotes && (
          <div className="mb-8">
            <PlayNoteList notes={demoNotes} />
          </div>
        )}

        <div className="mb-8">
          <TabToggle activeTab={activeTab} onTabChange={setActiveTab} />
        </div>

        <div className="mb-8">
          <ProgressSteps steps={progressSteps} />
        </div>

        <div className="space-y-6">
          {activeTab === 'file' ? (
            <>
              <FileUpload onFileSelect={handleFileSelect} />
              <FileList
                files={uploadedFiles}
                onRemoveFile={handleRemoveFile}
                onFileClick={handleFileClick}
                selectedIndex={selectedFileIndex}
              />
              {selectedFileIndex !== null && (
                <FilePreview
                  file={uploadedFiles[selectedFileIndex]}
                  onClose={() => setSelectedFileIndex(null)}
                />
              )}
              <UrlInput onUrlSubmit={handleUrlSubmit} />
            </>
          ) : (
            <TranscriptInput
              onSynthesize={(audioUrl) => {
                console.log('Audio ready:', audioUrl);
                // Handle the synthesized audio URL
              }}
            />
          )}


          <div>
            <h2 className="text-xl font-semibold mb-4">Choose Synthesis Style</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <VoiceStyleCard
                title="Podcast"
                description="in the conversational style of a podcast"
                icon={Mic}
                speakers={2}
                selected={selectedStyle === 'podcast'}
                onClick={() => setSelectedStyle('podcast')}
              />
              <VoiceStyleCard
                title="Executive Briefing"
                description="in the succinct style of a professional briefing"
                icon={Users}
                speakers={1}
                selected={selectedStyle === 'executive'}
                onClick={() => setSelectedStyle('executive')}
              />
              <VoiceStyleCard
                title="Children's Story"
                description="in the imaginative, colorful style of a children's book author"
                icon={BookOpen}
                speakers={1}
                selected={selectedStyle === 'children'}
                onClick={() => setSelectedStyle('children')}
              />
              <VoiceStyleCard
                title="Debate"
                description="in the contentious, aggressive style of a thoughtful discussion"
                icon={MessageSquare}
                speakers={2}
                selected={selectedStyle === 'debate'}
                onClick={() => setSelectedStyle('debate')}
              />
              <VoiceStyleCard
                title="Detailed Summary"
                description="a comprehensive and detailed summary of the content"
                icon={FileText}
                speakers={1}
                selected={selectedStyle === 'summary'}
                onClick={() => setSelectedStyle('summary')}
              />
              <VoiceStyleCard
                title="Parody"
                description="a humorous and satirical take on the content"
                icon={Theatre}
                speakers={1}
                selected={selectedStyle === 'parody'}
                onClick={() => setSelectedStyle('parody')}
              />
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Voice</h2>
            <VoiceSelector
              selectedVoice={selectedVoice}
              onVoiceChange={setSelectedVoice}
            />
            {showVoiceCreator ? (
              <div className="mt-4">
                <VoiceCreator />
              </div>
            ) : (
              <div className="mt-4">
                <CreateVoiceButton onClick={() => setShowVoiceCreator(true)} />
              </div>
            )}

            {processingStatus !== 'idle' && (
              <div className="mt-4">
                <ProcessingStatus
                  status={processingStatus}
                  message={
                    processingStatus === 'processing' ? 'Processing your voice samples...' :
                    processingStatus === 'complete' ? 'Voice training complete!' :
                    'Error processing voice samples'
                  }
                />
              </div>
            )}

            {processingStatus === 'processing' && (
              <div className="mt-4">
                <TrainingProgress {...trainingProgress} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;