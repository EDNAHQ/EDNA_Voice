import React from 'react';
import { Check } from 'lucide-react';

interface Step {
  label: string;
  completed: boolean;
  active: boolean;
}

interface ProgressStepsProps {
  steps: Step[];
}

export function ProgressSteps({ steps }: ProgressStepsProps) {
  return (
    <div className="flex items-center justify-between w-full">
      {steps.map((step, index) => (
        <React.Fragment key={step.label}>
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors ${
                step.completed
                  ? 'bg-green-500 border-green-500'
                  : step.active
                  ? 'border-green-500'
                  : 'border-gray-600'
              }`}
            >
              {step.completed ? (
                <Check className="w-4 h-4 text-white" />
              ) : (
                <span className={step.active ? 'text-green-500' : 'text-gray-600'}>
                  {index + 1}
                </span>
              )}
            </div>
            <span
              className={`text-sm mt-2 ${
                step.active ? 'text-green-500' : 'text-gray-500'
              }`}
            >
              {step.label}
            </span>
          </div>
          {index < steps.length - 1 && (
            <div
              className={`h-0.5 flex-1 mx-4 transition-colors ${
                step.completed ? 'bg-green-500' : 'bg-gray-600'
              }`}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}