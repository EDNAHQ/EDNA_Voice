import React from 'react';
import { FileText, File as FileIcon, X } from 'lucide-react';

interface FilePreviewProps {
  file: File;
  onClose: () => void;
}

export function FilePreview({ file, onClose }: FilePreviewProps) {
  const isText = file.type.includes('text') || file.type.includes('application/json');
  const isPDF = file.type === 'application/pdf';
  const isImage = file.type.startsWith('image/');

  const [content, setContent] = React.useState<string>('');
  const [objectUrl, setObjectUrl] = React.useState<string>('');

  React.useEffect(() => {
    if (isText) {
      const reader = new FileReader();
      reader.onload = (e) => setContent(e.target?.result as string);
      reader.readAsText(file);
    } else if (isImage || isPDF) {
      const url = URL.createObjectURL(file);
      setObjectUrl(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [file, isText, isImage, isPDF]);

  return (
    <div className="bg-gray-800/50 rounded-lg overflow-hidden">
      <div className="flex items-center justify-between p-4 bg-gray-800">
        <div className="flex items-center gap-3">
          {isText ? (
            <FileText className="w-5 h-5 text-blue-400" />
          ) : (
            <FileIcon className="w-5 h-5 text-purple-400" />
          )}
          <span className="text-gray-200 font-medium">{file.name}</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-700 rounded-full transition-colors"
        >
          <X className="w-4 h-4 text-gray-400" />
        </button>
      </div>
      <div className="p-4">
        {isText && (
          <pre className="text-sm text-gray-300 whitespace-pre-wrap max-h-96 overflow-auto">
            {content}
          </pre>
        )}
        {isImage && (
          <img
            src={objectUrl}
            alt={file.name}
            className="max-w-full h-auto rounded"
          />
        )}
        {isPDF && (
          <iframe
            src={objectUrl}
            className="w-full h-96 rounded"
            title={file.name}
          />
        )}
      </div>
    </div>
  );
}