import React, { useState } from 'react';
import { useTTS } from '../hooks/useTTS';
import { Play, Pause, Volume2, AlertCircle, Loader2 } from 'lucide-react';

interface TranscriptInputProps {
  onSynthesize?: (audioUrl: string) => void;
}

export function TranscriptInput({ onSynthesize }: TranscriptInputProps) {
  const [text, setText] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);

  const { synthesize, loading, error, status, audioUrl } = useTTS({
    onSuccess: (url) => {
      onSynthesize?.(url);
      const newAudio = new Audio(url);
      setAudio(newAudio);
      newAudio.addEventListener('ended', () => setIsPlaying(false));
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      synthesize(text);
    }
  };

  const togglePlay = () => {
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full h-48 bg-gray-800/50 text-gray-200 p-4 rounded-lg resize-none border border-gray-700 focus:border-green-500 focus:outline-none"
            placeholder="Enter or paste your text here..."
          />
          {error && (
            <div className="absolute bottom-4 right-4 text-red-500 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">Synthesis failed</span>
            </div>
          )}
        </div>

        <div className="flex justify-between items-center">
          <button
            type="submit"
            disabled={loading || !text.trim()}
            className="bg-green-500 hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                Synthesize
              </>
            )}
          </button>

          {audioUrl && (
            <button
              onClick={togglePlay}
              className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Play
                </>
              )}
            </button>
          )}
        </div>
      </form>

      {status && status !== 'completed' && (
        <div className="bg-gray-800/30 text-gray-400 p-4 rounded-lg flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span className="text-sm">
            {status === 'processing'
              ? 'Processing your text...'
              : 'Initializing synthesis...'}
          </span>
        </div>
      )}
    </div>
  );
}