import React from 'react';
import { useSubscriptionStore } from '../store/subscriptionStore';
import { STRIPE_CONFIG } from '../config/stripe';
import { Calendar, CheckCircle, AlertTriangle } from 'lucide-react';

export function SubscriptionStatus() {
  const subscription = useSubscriptionStore((state) => state.subscription);

  if (!subscription) return null;

  const plan = STRIPE_CONFIG.products[subscription.plan];
  const endDate = new Date(subscription.currentPeriodEnd);
  const minutesPercentage = (subscription.usage.minutes / plan.limits.minutes) * 100;
  const voicesPercentage = (subscription.usage.voices / plan.limits.voices) * 100;

  return (
    <div className="bg-gray-800/30 rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {subscription.status === 'active' ? (
            <CheckCircle className="w-5 h-5 text-green-500" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
          )}
          <span className="font-medium text-white">{plan.name}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <Calendar className="w-4 h-4" />
          <span>Renews {endDate.toLocaleDateString()}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Synthesis Minutes</span>
            <span className="text-gray-400">
              {subscription.usage.minutes} / {plan.limits.minutes}
            </span>
          </div>
          <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 rounded-full transition-all"
              style={{ width: `${minutesPercentage}%` }}
            />
          </div>
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Custom Voices</span>
            <span className="text-gray-400">
              {subscription.usage.voices} / {plan.limits.voices}
            </span>
          </div>
          <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 rounded-full transition-all"
              style={{ width: `${voicesPercentage}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}