import React from 'react';
import { Plus } from 'lucide-react';

interface CreateVoiceButtonProps {
  onClick: () => void;
}

export function CreateVoiceButton({ onClick }: CreateVoiceButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full py-3 border-2 border-dashed border-gray-700 rounded-lg text-green-500 hover:border-green-500 transition-colors flex items-center justify-center gap-2"
    >
      <Plus className="w-5 h-5" />
      Create New Voice
    </button>
  );
}