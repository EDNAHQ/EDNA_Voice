import React, { useCallback, useState } from 'react';
import { Upload, FileType, Plus, File as FileIcon } from 'lucide-react';
import { api } from '../services/api';
import { playai } from '../services/playai';
import { validateFile } from '../utils/file';
import { analytics } from '../utils/analytics';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

export function FileUpload({ onFileSelect }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);

  const handleUpload = async (file: File) => {
    const validation = validateFile(file);
    if (!validation.valid) {
      analytics.trackError(new Error(validation.error), {
        context: 'file_validation',
        fileType: file.type,
        fileSize: file.size,
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const response = await api.uploadFile(file, (progress) => {
        setUploadProgress(progress);
      });
      
      // After successful upload, start synthesis if URL is available
      if (response.data?.fileUrl) {
        await playai.synthesize({
          sourceFileUrl: response.data.fileUrl,
          synthesisStyle: 'podcast', // Default style, can be changed later
        });
      }

      analytics.trackEvent('file_upload_success', {
        fileType: file.type,
        fileSize: file.size,
      });

      onFileSelect(file);
    } catch (error) {
      analytics.trackError(error as Error, {
        context: 'file_upload',
        fileType: file.type,
        fileSize: file.size,
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.add('border-green-400');
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.remove('border-green-400');
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.remove('border-green-400');
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleUpload(file);
    }
  }, [onFileSelect]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleUpload(file);
    }
  }, [onFileSelect]);

  return (
    <div
      className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-gray-400 transition-colors"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {isUploading && (
        <div className="absolute inset-0 bg-gray-900/50 flex items-center justify-center">
          <div className="text-center">
            <div className="w-full max-w-xs bg-gray-800 rounded-full h-2 mb-2">
              <div
                className="bg-green-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            <span className="text-sm text-gray-400">
              Uploading... {Math.round(uploadProgress)}%
            </span>
          </div>
        </div>
      )}
      <div className="flex flex-col items-center gap-4">
        <div className="flex gap-2">
          <FileIcon className="w-12 h-12 text-green-500" />
          <Upload className="w-12 h-12 text-blue-500" />
          <Plus className="w-12 h-12 text-purple-500" />
        </div>
        <h3 className="text-xl font-semibold text-gray-200">
          Upload file(s) for Speech Synthesis
        </h3>
        <p className="text-gray-400 text-sm">
          [.PDF, .CSV, .TXT, .epub, .docx, .xls, .PNG, .JPEG, .WEBP, .MP4]
          <br />
          ...up to 50MB
        </p>
        <label className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg cursor-pointer transition-colors">
          <input
            type="file"
            className="hidden"
            onChange={handleFileInput} 
            accept={PLAYAI_CONFIG.SUPPORTED_FILE_TYPES.join(',')}
          />
          Upload file
        </label>
      </div>
    </div>
  );
}