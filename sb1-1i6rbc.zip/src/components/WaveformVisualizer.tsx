import React, { useEffect, useRef } from 'react';

interface WaveformVisualizerProps {
  audioData: number[];
  isRecording?: boolean;
}

export function WaveformVisualizer({ audioData, isRecording }: WaveformVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Set up styling
    ctx.lineWidth = 2;
    ctx.strokeStyle = isRecording ? '#22c55e' : '#4b5563';

    // Draw waveform
    ctx.beginPath();
    const sliceWidth = canvas.width / audioData.length;
    let x = 0;

    audioData.forEach((amplitude, i) => {
      const y = (amplitude * canvas.height) / 2 + canvas.height / 2;
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
      x += sliceWidth;
    });

    ctx.stroke();
  }, [audioData, isRecording]);

  return (
    <canvas
      ref={canvasRef}
      width={600}
      height={100}
      className="w-full h-24 bg-gray-800/30 rounded-lg"
    />
  );
}