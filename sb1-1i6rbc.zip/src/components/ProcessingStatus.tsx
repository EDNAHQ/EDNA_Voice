import React from 'react';
import { Loader2 } from 'lucide-react';

interface ProcessingStatusProps {
  status: 'idle' | 'processing' | 'complete' | 'error';
  message: string;
}

export function ProcessingStatus({ status, message }: ProcessingStatusProps) {
  return (
    <div className="flex items-center gap-3 p-4 rounded-lg bg-gray-800/30">
      {status === 'processing' && (
        <Loader2 className="w-5 h-5 text-green-500 animate-spin" />
      )}
      <span className={`text-sm ${
        status === 'error' ? 'text-red-400' :
        status === 'complete' ? 'text-green-400' :
        'text-gray-400'
      }`}>
        {message}
      </span>
    </div>
  );
}