import React, { ReactNode } from 'react';
import { useSubscriptionStore } from '../store/subscriptionStore';
import { Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SubscriptionGuardProps {
  feature: 'minutes' | 'voices';
  children: ReactNode;
}

export function SubscriptionGuard({ feature, children }: SubscriptionGuardProps) {
  const canUseFeature = useSubscriptionStore((state) => state.canUseFeature(feature));

  if (!canUseFeature) {
    return (
      <div className="bg-gray-800/30 rounded-lg p-6 text-center">
        <Lock className="w-8 h-8 text-gray-400 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-white mb-2">
          Feature not available
        </h3>
        <p className="text-gray-400 mb-4">
          Upgrade your plan to access this feature
        </p>
        <Link
          to="/pricing"
          className="inline-block bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg transition-colors"
        >
          View Plans
        </Link>
      </div>
    );
  }

  return <>{children}</>;
}