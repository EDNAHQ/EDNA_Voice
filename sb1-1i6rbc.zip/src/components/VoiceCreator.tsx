import React, { useState } from 'react';
import { Mic, Square, Play, Save, Settings } from 'lucide-react';
import { WaveformVisualizer } from './WaveformVisualizer';
import { ShortcutsHelp } from './ShortcutsHelp';
import { useKeyboardShortcuts } from '../hooks/useKeyboardShortcuts';
import { VoiceSettings } from './VoiceSettings';
import { VoicePresets } from './VoicePresets';

export function VoiceCreator() {
  const [isRecording, setIsRecording] = useState(false);
  const [recordings, setRecordings] = useState<string[]>([]);
  const [voiceName, setVoiceName] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState({
    pitch: 100,
    speed: 100,
    clarity: 75
  });

  // Simulated audio data - replace with real audio data in production
  const [audioData, setAudioData] = useState<number[]>(
    Array.from({ length: 100 }, () => Math.random() * 0.5)
  );

  useKeyboardShortcuts([
    { key: 'r', handler: () => setIsRecording(prev => !prev) },
    { key: 's', ctrl: true, handler: () => handleSave() },
    { key: 'Escape', handler: () => setShowSettings(false) },
  ]);

  const shortcuts = [
    { keys: ['R'], description: 'Start/Stop Recording' },
    { keys: ['Ctrl', 'S'], description: 'Save Voice' },
    { keys: ['Esc'], description: 'Close Settings' },
  ];

  const handleStartRecording = () => {
    setIsRecording(true);
    // Implement actual recording logic
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    setRecordings(prev => [...prev, `Recording ${prev.length + 1}`]);
  };

  const handleSave = () => {
    if (recordings.length > 0 && voiceName) {
      console.log('Saving voice:', voiceName);
    }
  };

  const handleSettingChange = (key: keyof typeof voiceSettings, value: number) => {
    setVoiceSettings(prev => ({ ...prev, [key]: value }));
  };

  const handlePresetSelect = (settings: typeof voiceSettings) => {
    setVoiceSettings(settings);
  };

  return (
    <div className="space-y-6 bg-gray-800/50 p-6 rounded-lg">
      <div className="flex justify-between items-start">
        <div className="flex-1">
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Voice Name
        </label>
        <input
          type="text"
          value={voiceName}
          onChange={(e) => setVoiceName(e.target.value)}
          className="w-full bg-gray-700/50 border border-gray-600 rounded-lg px-4 py-2 text-gray-200 focus:border-green-500 focus:ring-0"
          placeholder="Enter a name for your voice"
        />
        </div>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 hover:bg-gray-700/50 rounded-lg ml-4"
        >
          <Settings className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {showSettings && (
        <div className="space-y-4">
          <ShortcutsHelp shortcuts={shortcuts} />
          <VoiceSettings
            settings={voiceSettings}
            onChange={handleSettingChange}
          />
          <VoicePresets onSelect={handlePresetSelect} />
        </div>
      )}

      <div>
        <h3 className="text-sm font-medium text-gray-300 mb-4">Voice Samples</h3>
        <div className="space-y-4">
          {recordings.map((recording, index) => (
            <div
              key={index}
              className="flex items-center justify-between bg-gray-700/30 p-3 rounded-lg"
            >
              <div className="flex items-center gap-3">
                <Play className="w-4 h-4 text-green-500" />
                <span className="text-gray-300">{recording}</span>
              </div>
              <button className="text-gray-400 hover:text-red-400">
                <Square className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="py-4">
        <WaveformVisualizer
          audioData={audioData}
          isRecording={isRecording}
        />
      </div>

      <div className="flex flex-col items-center gap-4">
        <button
          onClick={isRecording ? handleStopRecording : handleStartRecording}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
            isRecording
              ? 'bg-red-500 hover:bg-red-600'
              : 'bg-green-500 hover:bg-green-600'
          }`}
        >
          {isRecording ? (
            <Square className="w-6 h-6 text-white" />
          ) : (
            <Mic className="w-6 h-6 text-white" />
          )}
        </button>
        <span className="text-sm text-gray-400">
          {isRecording ? 'Recording...' : 'Click to Record'}
        </span>
      </div>

      <button
        disabled={recordings.length === 0 || !voiceName}
        className="w-full py-3 bg-green-500 text-white rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-green-600 transition-colors"
      >
        <Save className="w-4 h-4" />
        Save Voice
      </button>
    </div>
  );
}