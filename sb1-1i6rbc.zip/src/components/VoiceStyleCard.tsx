import React from 'react';
import { type LucideIcon } from 'lucide-react';

interface VoiceStyleCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  speakers: number;
  selected?: boolean;
  onClick: () => void;
}

export function VoiceStyleCard({
  title,
  description,
  icon: Icon,
  speakers,
  selected,
  onClick,
}: VoiceStyleCardProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full p-4 rounded-lg text-left transition-all ${
        selected
          ? 'bg-green-600/10 border-2 border-green-500'
          : 'bg-gray-800/30 border-2 border-transparent hover:border-gray-600'
      }`}
    >
      <div className="flex items-start gap-3">
        <Icon className={`w-5 h-5 mt-1 ${selected ? 'text-green-500' : 'text-gray-400'}`} />
        <div>
          <h3 className="font-semibold text-gray-200">{title}</h3>
          <div className="text-sm text-gray-500 mt-1">
            {speakers} Speaker{speakers > 1 ? 's' : ''} · {description}
          </div>
        </div>
      </div>
    </button>
  );
}