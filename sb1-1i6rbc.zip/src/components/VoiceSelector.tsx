import React from 'react';
import { ChevronDown } from 'lucide-react';

interface VoiceSelectorProps {
  selectedVoice: string;
  onVoiceChange: (voice: string) => void;
}

export function VoiceSelector({ selectedVoice, onVoiceChange }: VoiceSelectorProps) {
  return (
    <div className="relative">
      <select
        value={selectedVoice}
        onChange={(e) => onVoiceChange(e.target.value)}
        className="w-full bg-gray-800/50 text-gray-200 px-4 py-3 pr-10 rounded-lg appearance-none border border-gray-700 hover:border-gray-600 transition-colors focus:outline-none focus:border-green-500"
      >
        <option value="deedee">Deedee</option>
        <option value="james">James</option>
        <option value="sarah">Sarah</option>
        <option value="michael">Michael</option>
      </select>
      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
    </div>
  );
}