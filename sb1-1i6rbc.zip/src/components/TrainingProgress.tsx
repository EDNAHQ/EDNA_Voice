import React from 'react';

interface TrainingProgressProps {
  progress: number;
  stage: string;
  totalStages: number;
  currentStage: number;
}

export function TrainingProgress({ progress, stage, totalStages, currentStage }: TrainingProgressProps) {
  return (
    <div className="space-y-3">
      <div className="flex justify-between text-sm">
        <span className="text-gray-400">Training Progress</span>
        <span className="text-gray-300">{Math.round(progress)}%</span>
      </div>
      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
        <div
          className="h-full bg-green-500 transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="flex justify-between text-xs">
        <span className="text-gray-500">Stage {currentStage} of {totalStages}</span>
        <span className="text-gray-400">{stage}</span>
      </div>
    </div>
  );
}