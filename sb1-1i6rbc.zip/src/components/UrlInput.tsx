import React, { useState } from 'react';
import { Link2 } from 'lucide-react';

interface UrlInputProps {
  onUrlSubmit: (url: string) => void;
}

export function UrlInput({ onUrlSubmit }: UrlInputProps) {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onUrlSubmit(url.trim());
      setUrl('');
    }
  };

  return (
    <div className="space-y-2">
      <div className="text-sm text-gray-400">OR ENTER A URL TO FETCH CONTENT</div>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com"
            className="w-full bg-gray-800 text-gray-200 px-4 py-2 rounded-lg pl-10 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
          <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          Fetch URL
        </button>
      </form>
    </div>
  );
}