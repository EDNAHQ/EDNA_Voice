import React from 'react';
import { Volume2, Zap, Sparkles } from 'lucide-react';

interface VoiceSettingsProps {
  settings: {
    pitch: number;
    speed: number;
    clarity: number;
  };
  onChange: (key: keyof typeof settings, value: number) => void;
}

export function VoiceSettings({ settings, onChange }: VoiceSettingsProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-gray-300">Voice Settings</h3>
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-gray-400">
              <Volume2 className="w-4 h-4" />
              Pitch
            </label>
            <span className="text-xs text-gray-500">{settings.pitch}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="200"
            value={settings.pitch}
            onChange={(e) => onChange('pitch', Number(e.target.value))}
            className="w-full accent-green-500"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-gray-400">
              <Zap className="w-4 h-4" />
              Speed
            </label>
            <span className="text-xs text-gray-500">{settings.speed}x</span>
          </div>
          <input
            type="range"
            min="50"
            max="150"
            value={settings.speed}
            onChange={(e) => onChange('speed', Number(e.target.value))}
            className="w-full accent-green-500"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-gray-400">
              <Sparkles className="w-4 h-4" />
              Clarity
            </label>
            <span className="text-xs text-gray-500">{settings.clarity}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={settings.clarity}
            onChange={(e) => onChange('clarity', Number(e.target.value))}
            className="w-full accent-green-500"
          />
        </div>
      </div>
    </div>
  );
}