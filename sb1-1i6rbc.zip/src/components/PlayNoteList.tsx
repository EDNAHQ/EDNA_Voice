import React from 'react';
import { Lock, Share2, MoreVertical } from 'lucide-react';

interface PlayNote {
  title: string;
  duration: string;
  type: 'DEBATE' | 'PODCAST' | 'DETAILED-SUMMARY' | 'TRANSCRIPT';
  locked?: boolean;
}

interface PlayNoteListProps {
  notes: PlayNote[];
}

export function PlayNoteList({ notes }: PlayNoteListProps) {
  return (
    <div className="space-y-2">
      <h2 className="text-sm font-medium text-gray-400 uppercase">YOUR PLAYNOTES</h2>
      <div className="space-y-2">
        {notes.map((note, index) => (
          <div
            key={index}
            className="bg-gray-800/50 rounded-lg p-4 flex items-center justify-between group hover:bg-gray-800/70 transition-colors"
          >
            <div className="flex items-center gap-3">
              {note.locked && <Lock className="w-4 h-4 text-gray-500" />}
              <div>
                <h3 className="text-gray-200 font-medium">{note.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm text-gray-500">{note.duration}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-gray-700/50 text-gray-300">
                    {note.type}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="p-2 hover:bg-gray-700/50 rounded-lg">
                <Share2 className="w-4 h-4 text-gray-400" />
              </button>
              <button className="p-2 hover:bg-gray-700/50 rounded-lg">
                <MoreVertical className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}