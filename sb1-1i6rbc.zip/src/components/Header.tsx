import React from 'react';
import { ChevronLeft, Box } from 'lucide-react';

export function Header() {
  return (
    <header className="flex items-center justify-between mb-8">
      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-gray-800 rounded-lg transition-colors">
          <ChevronLeft className="w-5 h-5 text-green-500" />
        </button>
        <div className="flex items-center gap-2">
          <Box className="w-6 h-6 text-green-500" />
          <h1 className="text-xl font-semibold text-white">Create Your PlayNote</h1>
        </div>
      </div>
      <div className="flex gap-2">
        <button className="px-4 py-2 rounded-lg bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors">
          Form
        </button>
        <button className="px-4 py-2 rounded-lg bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors">
          Code
        </button>
      </div>
    </header>
  );
}