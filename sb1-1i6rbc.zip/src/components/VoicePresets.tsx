import React from 'react';
import { Sparkles, Mic, Radio, Music, Video, Theatre } from 'lucide-react';

interface Preset {
  id: string;
  name: string;
  icon: typeof Sparkles;
  settings: {
    pitch: number;
    speed: number;
    clarity: number;
  };
}

interface VoicePresetsProps {
  onSelect: (settings: Preset['settings']) => void;
}

export function VoicePresets({ onSelect }: VoicePresetsProps) {
  const presets: Preset[] = [
    {
      id: 'broadcast',
      name: 'Broadcast',
      icon: Radio,
      settings: { pitch: 100, speed: 100, clarity: 80 }
    },
    {
      id: 'podcast',
      name: 'Podcast',
      icon: Mic,
      settings: { pitch: 100, speed: 95, clarity: 75 }
    },
    {
      id: 'singing',
      name: 'Singing',
      icon: Music,
      settings: { pitch: 110, speed: 90, clarity: 85 }
    },
    {
      id: 'narration',
      name: 'Narration',
      icon: Video,
      settings: { pitch: 95, speed: 85, clarity: 90 }
    },
    {
      id: 'character',
      name: 'Character',
      icon: Theatre,
      settings: { pitch: 120, speed: 105, clarity: 70 }
    }
  ];

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-medium text-gray-300">Voice Presets</h3>
      <div className="grid grid-cols-2 gap-2">
        {presets.map((preset) => {
          const Icon = preset.icon;
          return (
            <button
              key={preset.id}
              onClick={() => onSelect(preset.settings)}
              className="flex items-center gap-2 p-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/50 transition-colors"
            >
              <Icon className="w-4 h-4 text-green-500" />
              <span className="text-sm text-gray-300">{preset.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}