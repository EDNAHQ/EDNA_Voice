import React from 'react';
import { FileText, MessageSquare } from 'lucide-react';

interface TabToggleProps {
  activeTab: 'file' | 'transcript';
  onTabChange: (tab: 'file' | 'transcript') => void;
}

export function TabToggle({ activeTab, onTabChange }: TabToggleProps) {
  return (
    <div className="flex bg-gray-800/50 p-1 rounded-lg w-full">
      <button
        onClick={() => onTabChange('file')}
        className={`flex items-center gap-2 flex-1 justify-center px-4 py-2 rounded-md transition-colors ${
          activeTab === 'file'
            ? 'bg-gray-700 text-green-500'
            : 'text-gray-400 hover:text-gray-300'
        }`}
      >
        <FileText className="w-4 h-4" />
        File
      </button>
      <button
        onClick={() => onTabChange('transcript')}
        className={`flex items-center gap-2 flex-1 justify-center px-4 py-2 rounded-md transition-colors ${
          activeTab === 'transcript'
            ? 'bg-gray-700 text-green-500'
            : 'text-gray-400 hover:text-gray-300'
        }`}
      >
        <MessageSquare className="w-4 h-4" />
        Transcript
      </button>
    </div>
  );
}