import React from 'react';
import { Keyboard } from 'lucide-react';

interface Shortcut {
  keys: string[];
  description: string;
}

interface ShortcutsHelpProps {
  shortcuts: Shortcut[];
}

export function ShortcutsHelp({ shortcuts }: ShortcutsHelpProps) {
  return (
    <div className="bg-gray-800/30 rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <Keyboard className="w-4 h-4 text-gray-400" />
        <h3 className="text-sm font-medium text-gray-300">Keyboard Shortcuts</h3>
      </div>
      <div className="space-y-2">
        {shortcuts.map((shortcut, index) => (
          <div key={index} className="flex items-center justify-between text-sm">
            <span className="text-gray-400">{shortcut.description}</span>
            <div className="flex gap-1">
              {shortcut.keys.map((key, keyIndex) => (
                <kbd
                  key={keyIndex}
                  className="px-2 py-1 text-xs font-semibold text-gray-200 bg-gray-700 rounded border border-gray-600 min-w-[1.5rem] text-center"
                >
                  {key}
                </kbd>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}