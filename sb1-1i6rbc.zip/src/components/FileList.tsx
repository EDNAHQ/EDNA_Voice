import React from 'react';
import { FileText, Trash2 } from 'lucide-react';

interface FileListProps {
  files: File[];
  onRemoveFile: (index: number) => void;
  onFileClick: (index: number) => void;
  selectedIndex: number | null;
}

export function FileList({ files, onRemoveFile, onFileClick, selectedIndex }: FileListProps) {
  if (files.length === 0) return null;

  return (
    <div className="space-y-2">
      <div className="text-sm text-gray-400">UPLOADED FILES FOR SPEECH SYNTHESIS</div>
      <div className="space-y-2">
        {files.map((file, index) => (
          <div
            key={`${file.name}-${index}`}
            className={`bg-gray-800 rounded-lg p-4 flex items-center justify-between group cursor-pointer ${
              selectedIndex === index ? 'ring-2 ring-green-500' : ''
            }`}
            onClick={() => onFileClick(index)}
          >
            <div className="flex items-center gap-3">
              <FileText className="text-green-500" />
              <div>
                <div className="text-gray-200">{file.name}</div>
                <div className="text-sm text-gray-400">
                  {(file.size / 1024).toFixed(2)} KB
                </div>
              </div>
            </div>
            <button
              onClick={() => onRemoveFile(index)}
              className="text-gray-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
      <button className="w-full py-3 border-2 border-dashed border-gray-700 rounded-lg text-green-500 hover:border-green-500 transition-colors">
        + Add More Files
      </button>
    </div>
  );
}