import React from 'react';
import { Github, Mail } from 'lucide-react';

export function OAuthButtons() {
  const handleGithubLogin = () => {
    // In a real app, implement OAuth flow
    console.log('GitHub login clicked');
  };

  const handleGoogleLogin = () => {
    // In a real app, implement OAuth flow
    console.log('Google login clicked');
  };

  return (
    <div className="space-y-3">
      <button
        onClick={handleGithubLogin}
        className="w-full bg-gray-800 hover:bg-gray-700 text-white py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
      >
        <Github className="w-5 h-5" />
        Continue with GitHub
      </button>
      <button
        onClick={handleGoogleLogin}
        className="w-full bg-gray-800 hover:bg-gray-700 text-white py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
      >
        <Mail className="w-5 h-5" />
        Continue with Google
      </button>
    </div>
  );
}