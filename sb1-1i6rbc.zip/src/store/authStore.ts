import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  name: string;
  emailVerified?: boolean;
  provider?: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  session: {
    expiresAt: number;
    token: string;
  } | null;
  login: (user: User) => void;
  logout: () => void;
  updateSession: (token: string) => void;
  verifyEmail: (email: string) => void;
  resetPassword: (email: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      session: null,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      updateSession: (token) => set({
        session: {
          token,
          expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
        },
      }),
      verifyEmail: (email) => {
        // In a real app, make API call to verify email
        console.log('Verifying email:', email);
      },
      resetPassword: (email) => {
        // In a real app, make API call to reset password
        console.log('Resetting password for:', email);
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);