import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { STRIPE_CONFIG } from '../config/stripe';

export type PlanType = 'basic' | 'pro';

interface Usage {
  minutes: number;
  voices: number;
}

interface Subscription {
  id: string;
  status: 'active' | 'canceled' | 'past_due';
  plan: PlanType;
  currentPeriodEnd: string;
  usage: Usage;
}

interface SubscriptionState {
  subscription: Subscription | null;
  setSubscription: (subscription: Subscription | null) => void;
  clearSubscription: () => void;
  updateUsage: (usage: Partial<Usage>) => void;
  canUseFeature: (feature: keyof Usage) => boolean;
}

export const useSubscriptionStore = create<SubscriptionState>()(
  persist(
    (set, get) => ({
      subscription: null,
      setSubscription: (subscription) => set({ subscription }),
      clearSubscription: () => set({ subscription: null }),
      updateUsage: (usage) => {
        const current = get().subscription;
        if (current) {
          set({
            subscription: {
              ...current,
              usage: { ...current.usage, ...usage },
            },
          });
        }
      },
      canUseFeature: (feature) => {
        const sub = get().subscription;
        if (!sub || sub.status !== 'active') return false;
        
        const plan = STRIPE_CONFIG.products[sub.plan];
        const currentUsage = sub.usage[feature];
        return currentUsage < plan.limits[feature];
      },
    }),
    {
      name: 'subscription-storage',
    }
  )
);