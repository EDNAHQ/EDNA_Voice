// Simple analytics wrapper - replace with your preferred analytics service
export const analytics = {
  trackEvent: (eventName: string, properties?: Record<string, any>) => {
    if (import.meta.env.PROD) {
      // In production, send to real analytics service
      console.log('Analytics Event:', eventName, properties);
    }
  },

  trackError: (error: Error, context?: Record<string, any>) => {
    if (import.meta.env.PROD) {
      // In production, send to error tracking service
      console.error('Error:', error, context);
    }
  },

  trackTiming: (category: string, variable: string, value: number) => {
    if (import.meta.env.PROD) {
      // In production, send performance metrics
      console.log('Timing:', { category, variable, value });
    }
  },
};