import { PLAYAI_CONFIG } from '../config/constants';

export function validateFile(file: File): { valid: boolean; error?: string } {
  const extension = `.${file.name.split('.').pop()?.toLowerCase()}`;
  
  if (!PLAYAI_CONFIG.SUPPORTED_FILE_TYPES.includes(extension)) {
    return {
      valid: false,
      error: `Unsupported file type. Supported types: ${PLAYAI_CONFIG.SUPPORTED_FILE_TYPES.join(', ')}`
    };
  }

  if (file.size > PLAYAI_CONFIG.MAX_FILE_SIZE) {
    return {
      valid: false,
      error: `File too large. Maximum size is ${PLAYAI_CONFIG.MAX_FILE_SIZE / (1024 * 1024)}MB`
    };
  }

  return { valid: true };
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}